# Models

Place trained model files here (e.g. `speech_cnn_bigru.keras`). Large files are git-ignored;
use Git LFS or a release asset if you want to version them.
