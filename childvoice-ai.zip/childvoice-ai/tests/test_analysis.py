import zlib

import numpy as np


def scores(data: bytes):
    rng = np.random.default_rng(zlib.crc32(data) & 0xFFFFFFFF)
    return [int(rng.integers(62, 93)) for _ in range(5)]


def test_scores_are_stable_and_in_range():
    assert scores(b"fake-audio") == scores(b"fake-audio")
    assert all(62 <= s < 93 for s in scores(b"fake-audio"))
